import setuptools
setuptools.setup(
    name="kchu_package",
    version="1.0.0",
    author="Kevin Clyde Chu",
    author_email="kchu.projects@gmail.com",
    description="Packt Python Workshop example package",
    long_description="My package's longer description and will appear in the web.",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)